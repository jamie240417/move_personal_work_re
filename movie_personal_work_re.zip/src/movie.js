/*const options = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlY2FhMGY2NWQzMmY2Njg2OGM1OGZkMjI4ZGJlMWQzMiIsInN1YiI6IjY2MmEwMzVhZGUxMWU1MDA5YjcwZDdhZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.DbUoAYRKH46tv2TJ6UCw3r4cecF0LNGd7avpOSbYl3A'
  }
};

fetch('https://api.themoviedb.org/3/movie/top_rated?language=en-US&page=1', options)
  .then(response => response.json())
  .then(response => console.log(response))
  .catch(err => console.error(err)); */



//exprt 로 main.js와 연결
export const generateMovieCards = async () => {
  const movies = await fetchMovieData();
  const cardList = document.querySelector("#card-list");
  //movies라는 변수의 정보를 "HTML:#card-list"에 담아준다.
  cardList.innerHTML = movies
  //innerHTML = movies HTML 안쪽에 movie에 대한 정보를 담아라. 전부 문자열
    .map( //movies.map movies의 갯수만큼 회전됨
      (movie) => `
          <li class="movie-card" id=${movie.id}> 
              <img src="https://image.tmdb.org/t/p/w500${posterpath}" alt="${movie.title}">
              <h3 class="movie-title">${movie.title}</h3>
              <p>${movie.overview}</p>
              <p>Rating: ${movie.vote_average}</p>
          </li>`
    )
    .join(""); //join() 메서드는 배열의 모든 요소를 연결해 하나의 문자열로 만듦.
//movie.id 로 들어감
  cardList.addEventListener("click", handleClickCard);

  // 이벤트 위임: 하위요소에서 발생한 이벤트를 상위요소에서 처리하도록 해줍니다.
  /* ul 태그에 handleClickCard 를 심어두면 모든 카드에 접근가능하다
  자식요소인 li를 선택해도 ul을 선택한것 처럼 실행이 가능하다는 뜻*/
  
  function handleClickCard(event) {
    // 카드 외 영역 클릭 시 무시

    if (event.target === cardList) return;

    if (event.target.matches(".movie-card")) {
      alert(`영화 id: ${event.target.id}`);
    } else {
      /* 카드의 자식 태그 (img, h3, p) 클릭 시 부모의 id로 접근
      event.target: 이벤트 발생한 요소
      event.currentTaget:이벤트 핸들러가 등록되어있는 요소*/
      alert(`영화 id: ${event.target.parentNode.id}`);
    }
  }
};

async function fetchMovieData() {
  const options = {
    method: "GET",
    headers: {
     accept: 'application/json',
    Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlY2FhMGY2NWQzMmY2Njg2OGM1OGZkMjI4ZGJlMWQzMiIsInN1YiI6IjY2MmEwMzVhZGUxMWU1MDA5YjcwZDdhZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.DbUoAYRKH46tv2TJ6UCw3r4cecF0LNGd7avpOSbYl3A',
    },
  };
  const response = await fetch(
    'https://api.themoviedb.org/3/movie/top_rated?language=en-US&page=1',
    options
  );
  const data = await response.json();
  return data.results;
}

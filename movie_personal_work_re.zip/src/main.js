import { generateMovieCards } from "./movie.js";
import { handleSearch } from "./search.js";

generateMovieCards();

const searchInput = document.querySelector("#search-input"); 
// html 태그를 다룰 수 있게 도와주는 함수인 querySelector 함수. ("#search-input") 를 찾아서 정보를 담아두었다.
searchInput.focus();
//focus();라는 메서드로  searchInput(="#search-input")를 찾고있음.

const form = document.querySelector("#search-form");
// html 태그를 다룰 수 있게 도와주는 함수인 querySelector 함수. ("#search-form") 를 찾아서 정보를 담아두었다.
form.addEventListener("submit", (event) => {
  event.preventDefault();
  handleSearch(searchInput.value);
});